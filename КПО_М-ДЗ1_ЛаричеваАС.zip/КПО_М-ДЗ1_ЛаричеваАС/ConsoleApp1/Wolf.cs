﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Волк
    /// </summary>
    public class Wolf : Predator
    {
        public Wolf(int number, int foodConsumption = 8)
            : base(number,"Wolf", foodConsumption) { }
    }
}
