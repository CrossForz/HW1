﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Тигр
    /// </summary>
    public class Tiger : Predator
    {
        public Tiger(int number, int foodConsumption = 10)
            : base(number, "Tiger", foodConsumption) { }
    }
}
