﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Ветклиника
    /// </summary>
    public class VeterinaryClinic : IVeterinaryClinic
    {
        public void GetHealth(Animal animal)
        {
            Random rnd = new Random();
            animal.Health = rnd.Next(1, 10);
        }
        public bool CheckHealth(Animal animal)
        {
            return animal.Health > 3;
        }
    }
}
