﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Сотрудник
    /// </summary>
    public class Staff : IPerson
    {
        public int EmployeeId { get; private set; }
        public string FullName { get; private set; }

        public Staff(int employeeId, string fullName = "ФИО")
        {
            EmployeeId = employeeId;
            FullName = fullName;
        }

    }
}
