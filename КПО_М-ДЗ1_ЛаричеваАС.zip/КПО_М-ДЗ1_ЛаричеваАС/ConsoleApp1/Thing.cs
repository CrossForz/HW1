﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Абстрактный класс для предметов
    /// </summary>
    public abstract class Thing : IInventory
    {
        public int Number { get; private set; }
        public string Name { get; protected set; }

        protected Thing(int number, string name)
        {
            Number = number;
            Name = name;
        }
    }
}
