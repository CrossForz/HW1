﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Абстрактный класс для травоядных
    /// </summary>
    public abstract class Herbo : Animal
    {
        public int KindnessLevel { get; private set; } // Уровень доброты

        public Herbo(int number, string name, int kindnessLevel, int foodConsumption)
            : base(number, name)
        {
            KindnessLevel = kindnessLevel;
            Food = foodConsumption; // Присваиваем переданное значение
        }
    }
}
