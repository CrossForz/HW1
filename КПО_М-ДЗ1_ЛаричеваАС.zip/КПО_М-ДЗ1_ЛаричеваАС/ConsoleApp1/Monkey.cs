﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Обезьяна
    /// </summary>
    public class Monkey : Herbo
    {
        public Monkey(int number, int kindnessLevel, int foodConsumption = 6)
            : base(number, "Monkey", kindnessLevel, foodConsumption) { }
    }
}
