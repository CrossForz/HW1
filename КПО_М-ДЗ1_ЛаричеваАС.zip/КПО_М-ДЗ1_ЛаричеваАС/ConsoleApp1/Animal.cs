﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Абстрактный класс животных
    /// </summary>
    public abstract class Animal : IAlive, IInventory
    {
        public int Number { get; private set; }
        public int Food { get; protected set; }
        public string Name { get; private set; }
        public int Health { get; set; }
        protected Animal(int number, string name, int health = 0)
        {
            Number = number;
            Name = name;
        }
    }
}
