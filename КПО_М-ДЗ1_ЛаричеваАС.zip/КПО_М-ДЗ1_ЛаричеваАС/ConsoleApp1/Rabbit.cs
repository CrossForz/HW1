﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Кролик
    /// </summary>
    public class Rabbit : Herbo
    {
        public Rabbit(int number, int kindnessLevel, int foodConsumption = 2)
            : base(number, "Rabbit", kindnessLevel, foodConsumption) { }
    }
}
