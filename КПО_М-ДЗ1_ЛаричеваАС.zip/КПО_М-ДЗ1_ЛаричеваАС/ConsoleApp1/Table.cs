﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Стол
    /// </summary>
    public class Table : Thing
    {
        public Table(int number) : base(number, "Table") { }
    }
}
