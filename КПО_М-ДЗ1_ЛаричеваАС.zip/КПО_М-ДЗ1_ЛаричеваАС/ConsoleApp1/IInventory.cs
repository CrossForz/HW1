﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Интерфейс для инвентаря
    /// </summary>
    public interface IInventory
    {
        int Number { get; }
    }
}
