﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Интерфейс ветклиники
    /// </summary>
    public interface IVeterinaryClinic
    {
        /// <summary>
        /// Метод для дачи уровня здоровья
        /// </summary>
        /// <param name="animal"></param>
        void GetHealth(Animal animal);
        /// <summary>
        /// Метод для определения, здорово ли животное
        /// </summary>
        /// <param name="animal"></param>
        bool CheckHealth(Animal animal);
    }
}
