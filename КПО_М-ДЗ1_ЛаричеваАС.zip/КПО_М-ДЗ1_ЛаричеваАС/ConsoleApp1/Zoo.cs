﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /// <summary>
    /// Зоопарк
    /// </summary>
    public class Zoo
    {
        private List<Animal> animals = new List<Animal>();
        private List<Thing> inventory = new List<Thing>();
        private List<IPerson> staff = new List<IPerson>();
        private IVeterinaryClinic veterinaryClinic;

        public Zoo(IVeterinaryClinic clinic)
        {
            veterinaryClinic = clinic;
        }
        public void AddStaff(Staff employee)
        {
            staff.Add(employee);
            Console.WriteLine($"Сотрудник {employee.FullName} ID {employee.EmployeeId} добавлен в зоопарк.");
        }

        public void AddThing(Thing thing)
        {
            inventory.Add(thing);
            Console.WriteLine($"{thing.Name} {thing.Number} добавлен в инвентарь зоопарка.");
        }

        public void AddAnimal(Animal animal)
        {
            veterinaryClinic.GetHealth(animal);
            if (veterinaryClinic.CheckHealth(animal))
            {
                animals.Add(animal);
                Console.WriteLine($"{animal.Name} {animal.Number} принят в зоопарк. Здоровье {animal.Health}.");
            }
            else
            {
                Console.WriteLine($"{animal.Name} не принят в зоопарк. Здоровье {animal.Health}.");
            }
        }

        public void ShowAnimalFoodRequirements()
        {
            int totalFood = 0;
            Console.WriteLine("Сколько еды нужно каждому животному:");
            foreach (var animal in animals)
            {
                totalFood += animal.Food;
                Console.WriteLine($"{animal.Name} {animal.Number}: {animal.Food} кг еды в день.");
            }
            Console.WriteLine($"Общее количество еды, необходимое всем животным: {totalFood} кг в день.");
        }
        public void CountAnimal()
        {
            int count = 0;
            foreach (var animal in animals)
            {
                count++;
            }
            Console.WriteLine($"Количество всех животных: {count}.");
        }

        public void ShowContactZooAnimals()
        {
            Console.WriteLine("Животные, подходящие для контактного зоопарка:");
            foreach (var animal in animals.OfType<Herbo>().Where(h => h.KindnessLevel > 5))
            {
                Console.WriteLine($"{animal.Name} (№ {animal.Number}) Уровень доброты {animal.KindnessLevel}");
            }
        }

        public void ShowInventory()
        {
            Console.WriteLine("Инвентаризация:");
            foreach (Thing item in inventory)
            {
                Console.WriteLine($"{item.Name} (№ {item.Number})");
            }

            foreach (Animal animal in animals)
            {
                Console.WriteLine($"{animal.Name} (№ {animal.Number})");
            }
        }
        public void ShowStaff()
        {
            Console.WriteLine("Список сотрудников:");
            foreach (IPerson employee in staff)
            {
                Console.WriteLine($"{employee.FullName} (ID: {employee.EmployeeId})");
            }
        }
    }
}
