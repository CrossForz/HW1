﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class AppConf
    {
        public static ServiceProvider ConfigureServices()
        {
            var serviceCollection = new ServiceCollection();

            serviceCollection.AddSingleton<IVeterinaryClinic, VeterinaryClinic>(); // регистрируем сервис для Ветклиники
            serviceCollection.AddSingleton<Zoo>(); // регистрируем сервис Зоопарка

            return serviceCollection.BuildServiceProvider();
        }
    }
}
