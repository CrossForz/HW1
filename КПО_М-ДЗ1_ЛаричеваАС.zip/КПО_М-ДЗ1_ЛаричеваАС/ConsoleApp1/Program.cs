﻿using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.Metrics;
namespace ConsoleApp1
{
    class Program
    {
        /// <summary>
        /// Метод заполнения готовыми данными
        /// </summary>
        /// <param name="zoo"></param>
        static void GoData(ref Zoo zoo)
        {
            zoo.AddThing(new Computer(1));
            zoo.AddThing(new Table(2));
            zoo.AddThing(new Table(3));
            zoo.AddStaff(new Staff (1, "Иван Иванович"));
            zoo.AddAnimal(new Monkey(4, 3, 7));
            zoo.AddAnimal(new Monkey(5, 6, 5));
            zoo.AddAnimal(new Rabbit(6, 9, 2));
            zoo.AddAnimal(new Wolf(7, 9));
            zoo.AddAnimal(new Tiger(8, 10));
        }
        /// <summary>
        /// Метод ручного заполнения
        /// </summary>
        /// <param name="zoo"></param>
        static void GoHandle(ref Zoo zoo)
        {
            int count = 0;
            int countID = 0;
            string select_v;
            do
            {
                Console.WriteLine("Введите номер варианта (только число):\n1.Monkey\n2.Rabbit\n3.Wolf\n4.Tiger\n5.Computer\n6.Table\n7.Staff");
                select_v = Console.ReadLine();
                switch (select_v)
                {
                    case "1":
                    case "2":
                        {
                            Console.WriteLine("Введите уровень доброты от 0 до 10 (целое число):");
                            int kind = int.TryParse(Console.ReadLine(), out kind) ? kind : 4;
                            Console.WriteLine("Введите количество еды (положительное целое число):");
                            int eat = int.TryParse(Console.ReadLine(), out eat) ? eat : 4;
                            if (select_v == "1")
                            {
                                Monkey monkey = new Monkey(++count, kind, eat);
                                zoo.AddAnimal(monkey);
                                if (monkey.Health < 5) { --count; }
                            }
                            else
                            {
                                Rabbit rabbit = new Rabbit(++count, kind, eat);
                                zoo.AddAnimal(rabbit);
                                if (rabbit.Health < 5) { --count; }
                            }
                            break;
                        }
                    case "3":
                    case "4":
                        {
                            Console.WriteLine("Введите количество еды (положительное целое число):");
                            int eat = int.TryParse(Console.ReadLine(), out eat) ? eat : 8;
                            if (select_v == "3")
                            {
                                Wolf wolf = new Wolf(++count, eat);
                                zoo.AddAnimal(wolf);
                                if (wolf.Health < 5) { --count; }
                            }
                            else
                            {
                                Tiger tiger = new Tiger(++count, eat);
                                zoo.AddAnimal(tiger);
                                if (tiger.Health < 5) { --count; }
                            }
                            break;
                        }
                    case "5": zoo.AddThing(new Computer(++count)); break;
                    case "6": zoo.AddThing(new Table(++count)); break;
                    case "7": Console.WriteLine("Введите ФИО"); zoo.AddStaff(new Staff(++countID, Console.ReadLine())); break;
                    default: Console.WriteLine("Неверный вариант"); break;
                }
                Console.WriteLine("Чтобы продолжить ввод, нажмите Enter");
            }
            while (Console.ReadKey().Key == ConsoleKey.Enter);
        }
        /// <summary>
        /// Метод результатов для заполенного зоопарка
        /// </summary>
        /// <param name="zoo"></param>
        static void ResultsZoo(Zoo zoo)
        {
            zoo.ShowInventory();
            zoo.ShowContactZooAnimals();
            zoo.ShowAnimalFoodRequirements();
            zoo.ShowStaff();
            zoo.CountAnimal();
        }
        static void Main()
        {
            var serviceProvider = AppConf.ConfigureServices();
            var zoo = serviceProvider.GetService<Zoo>();
            Console.WriteLine("Введите номер варианта (только число):\n1. Показ работы на заготовленных данных\n2. Ручное добавление");
            string select_v = Console.ReadLine();
            if (select_v == "1")
            {
                GoData(ref zoo);
                ResultsZoo(zoo);
            }
            else if (select_v == "2")
            {
                GoHandle(ref zoo);
                ResultsZoo(zoo);
            }
            else
            {
                Console.WriteLine("Неверный вариант");
            }
        }
    }
}

